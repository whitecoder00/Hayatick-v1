<!DOCTYPE html>
<html>
<head>
<meta charset='UTF-8'/>
<title>Port scan</title><center>
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<form method='post' action=''>
<center style="color:#fff;">Host: <br><input type=text name=host></input></center>
<center style="color:#fff;">Port first: <br><input type=text name=first></input></center>
<center style="color:#fff;">end Port: <br><input type=text name=end></input></center><br>
<input type=submit value='Scan'></input><br>
</form>
 
<?php
ignore_user_abort(FALSE);
error_reporting(FALSE);
set_time_limit(0);
 
$ip =& $_POST['host'];
$inicio  =& $_POST['first'];
$fim  =& $_POST['end'];
$tamanho =  strlen($ip);
 
if ($tamanho > 0){
echo "<font color=Red size=5>sorry The port is closed not be displayed !</font><br><br><font color=Black size5>Scan started in: ". $ip ."<br></font>";
echo date("d/m/y")."~".date("H:i");
echo "<br><hr width=340>";
while ($inicio < $fim){
$inicio++;
$porta = $inicio;
$fp = fsockopen($ip,$porta,$errno,$errstr,10);
if($fp == TRUE){
echo "<br><font color=Black size=6>";
print"<b><font color='Green'>the $port is open<b><br></font>";
echo "</font>";
fclose($fp);
}}}
?>
</center>
</html>