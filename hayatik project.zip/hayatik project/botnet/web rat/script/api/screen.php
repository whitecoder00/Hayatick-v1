<?php
	if($name!=NULL)
	{
		$screencon=mysql_connect($host,$user,$pass);
		mysql_select_db($db,$screencon);
		$selscreen=mysql_query("select * from bscreen where sname='".$name."'");
		$rowscreen=mysql_fetch_array($selscreen);
		echo "<~wi~>".$rowscreen['swidth']."<~wi~>";
		echo "<~hi~>".$rowscreen['shight']."<~hi~>";
		if(isset($_FILES['file']))
		{
		$dir=getcwd();
		$upload=$dir."/admin/files/clinets/".$name."/".basename("s.jpg");
		
			move_uploaded_file($_FILES['file']['tmp_name'],$upload);
			echo $_FILES['file']['type'];
		}
	}
?>