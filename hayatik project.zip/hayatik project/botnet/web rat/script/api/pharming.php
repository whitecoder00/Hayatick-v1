<?php
	if($name!=NULL)
	{
		$pharmingcon=mysql_connect($host,$user,$pass);
		mysql_select_db($db,$pharmingcon);
		$selpharming=mysql_query("select * from bpharming where sname='".$name."'");
		$rowpharming=mysql_fetch_array($selpharming);
		if($rowpharming['sweb']!=NULL)
		{
			echo "<~ip~>".$rowpharming['sip']."<~ip~><~web~>".$rowpharming['sweb']."<~web~><~code~><!--".$rowpharming['scode']."--><~code~>";
		
			//$pharmingcon=mysqli_connect($host,$user,$pass,$db);
				//mysqli_query($pharmingcon,"update bpharming set sip=NULL , sweb=NULL , scode=NULL where sname='".$name."'");
			//mysqli_close($pharmingcon);
		}

	}
?>