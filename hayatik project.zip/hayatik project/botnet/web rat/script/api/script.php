

<?php
	if($name!=NULL)
	{
		$scriptcon=mysql_connect($host,$user,$pass);
		mysql_select_db($db,$scriptcon);
		$selsacrpt=mysql_query("select * from bscript where sname='".$name."'");
		$rowscript=mysql_fetch_array($selsacrpt);
		
		if($rowscript['scode']!=NULL)
		{
			echo "<~code~>".$rowscript['scode']."<~code~><~format~>".$rowscript['sformat']."<~format~>";
			
			include("nullorder.php");
			saveorder(0);
			
		}
	}
?>