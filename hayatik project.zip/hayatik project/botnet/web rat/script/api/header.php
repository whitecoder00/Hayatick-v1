<?php
	function fud_head($post_get)
	{
		$post_get=str_replace("<","&lt;",$post_get);
		$post_get=str_replace(">","&gt;",$post_get);
		$post_get=str_replace("'","&apos;",$post_get);
		$post_get=str_replace(",","",$post_get);
		$post_get=str_replace("/","",$post_get);

		return mysql_real_escape_string($post_get);
		
	}
?>