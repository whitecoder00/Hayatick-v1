<?php
$lookup = json_decode(file_get_contents("http://ipinfo.io/".$ipjson."/json/"));
?>