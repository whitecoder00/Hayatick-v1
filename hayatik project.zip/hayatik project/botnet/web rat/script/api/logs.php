<?php
	if($name!=NULL)
	{
		$logcon=mysql_connect($host,$user,$pass);
		mysql_select_db($db,$logcon);
		$sellog=mysql_query("select * from blogs");
		$rowlog=mysql_fetch_array($sellog);
		
			$logcon=mysqli_connect($host,$user,$pass,$db);
				mysqli_query($logcon,"update blogs set blog='new connect clinet [".$name."->".date ("Y-m-d H:i:s")."]"."\n".$rowlog['blog']."'");
			mysqli_close($logcon);
	}
?>