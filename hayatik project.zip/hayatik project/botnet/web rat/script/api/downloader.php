<?php
	if($name!=NULL)
	{
		$downloaderrcon=mysql_connect($host,$user,$pass);
		mysql_select_db($db,$downloaderrcon);
		$seldownloader=mysql_query("select * from bdownloader where sname='".$name."'");
		$rowdownloader=mysql_fetch_array($seldownloader);
		
		if($rowdownloader['slink']!=NULL)
		{
			echo $rowdownloader['slink'];
			include("nullorder.php");
			saveorder(0);
		}

	}
?>