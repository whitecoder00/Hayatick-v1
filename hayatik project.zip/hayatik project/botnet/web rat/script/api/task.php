<?php
	if($name!=NULL)
	{
		$taskcon=mysql_connect($host,$user,$pass);
		mysql_select_db($db,$taskcon);
		$seltask=mysql_query("select * from btask where sname='".$name."'");
		$taskrow=mysql_fetch_array($seltask);

		$taskcon=mysqli_connect($host,$user,$pass,$db);
			mysqli_query($taskcon,"update btask set stask='".$taskrow['stask'].fud_head($_GET['poc'])."' where sname='".$name."'");
		mysqli_close($taskcon);

			include("nullorder.php");
			saveorder(0);
	}
?>