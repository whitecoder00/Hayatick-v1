<?php
	if($name!=NULL)
	{
			$chatcon=mysql_connect($host,$user,$pass);
			mysql_select_db($db,$chatcon);
			$selchat=mysql_query("select * from bchat where sname='".$name."'");
			$rowchat=mysql_fetch_array($selchat);

		if($_GET['chatlog']==1)
		{
			if($rowchat['sname']!=NULL)
			{
				echo $rowchat['schat'];
			}
		}
		elseif($_GET['chatlog']==2)
		{
		$chat=$rowchat["schat"]."\n".$name.">".fud_head($_GET["chatdata"]);
		$chat=str_replace("'","",$chat);
			$chatcon=mysqli_connect($host,$user,$pass,$db);
				mysqli_query($chatcon,"update bchat set schat='".$chat."' where sname='".$name."'");
			mysqli_close($chatcon);
			
		}
	}
?>