<?php
	if($name!=NULL)
	{
		$servercon=mysql_connect($host,$user,$pass);
		mysql_select_db($db,$servercon);
		$selserver=mysql_query("select * from bserver where sname='".$name."'");
		$rowserver=mysql_fetch_array($selserver);
		
		if($rowserver['scommand']!=NULL)
		{
			echo "<~>".$rowserver['scommand']."<~>";
			
			include("nullorder.php");
			saveorder(0);
						
			$servercon=mysqli_connect($host,$user,$pass,$db);
				mysqli_query($servercon,"update bserver set scommand=NULL where sname='".$name."'");
			mysqli_close($servercon);
		}
	}
?>