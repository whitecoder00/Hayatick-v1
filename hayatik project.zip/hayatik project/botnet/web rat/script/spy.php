<?php       ////////////////////// BOT API \\\\\\\\\\\\\\\\\
		include("config.php");
		include("api/header.php");
		include("api/user.php");

	$page="index";
	if(isset($_GET['page']))
	{
		$page=fud_head($_GET['page']); // <- please edited :)

			if(isset($_GET['page']))

				include("api/".basename($page).".php");		
	}

	echo "</{order}><!--".$row['sorder']."--></{order}>";
?>
