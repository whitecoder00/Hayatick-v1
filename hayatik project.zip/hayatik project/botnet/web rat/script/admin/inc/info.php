<?php
	include("chk.php");
?>
<div class="panel panel-default lookup">
<div style="">
	<?php
		$lookup = json_decode(file_get_contents("http://ipinfo.io/".$_GET['ip']."/json/"));
		$whois=file_get_contents("http://www.whois.com/whois/".$_GET['ip']);
	?>
		<center><h2><b>INFO</b></h2></center>
		<br>
		<br>
		<pre>
	<b>Ip</b> : <?php echo $lookup->ip;?>
	<br>
	<b>Host-Name</b> : <?php echo $lookup->hostname;?>
	<br>
	<b>City</b> : <?php echo $lookup->city;?>
	<br>
	<b>Region</b> :<?php echo $lookup->region;?>
	<br>
	<b>Country</b> : <?php echo $lookup->country;?>
	<br>
	<b>Location</b> : <?php echo $lookup->loc;?>
	<br>
	<b>ORG</b> : <?php echo $lookup->org;?>
	<br>
	<br>
	<?php
		$whois=strstr($whois,"% This is the RIPE Database query service.");
		$whois=substr($whois,0,strpos($whois,"% This query was served by the RIPE Database Query Service version 1.80.1 (DB-2)"));
		echo $whois;
	?>
</div>
</div>