<?php
	include("../check.php");
	include("../../config.php");
	include("chk.php");
?>
<?php
					include("../../config.php");
					$con=mysql_connect($host,$user,$pass);
					mysql_select_db($db,$con);
					$sel=mysql_query("select * from btask where sname='".$_GET['user']."'");
					$row=mysql_fetch_array($sel);
					$task=$row['stask'];
					//  <tr>=~~ // </tr>=!! // <td>=@@ // </td>=##
					$task=str_replace("~tr~","<tr>",$task);
					$task=str_replace("~`tr~","</tr>",$task);
					$task=str_replace("~td~","<td>",$task);
					$task=str_replace("~`td~","</td>",$task);
					echo $task;

?>