<?php
	include("../check.php");
	include("../../config.php");
	include("chk.php");
?>
<?php
	$op=fopen("../files/clinets/".$_GET['user']."/s.jpg","r") or die("files/clinets/".$_GET['user']."/s.jpg");
		$b64=fread($op,filesize("../files/clinets/".$_GET['user']."/s.jpg"));
	fclose($op);
	
	echo "<img src='data:image/png;base64,".base64_encode($b64)."' id='sc'>";
?>