<?php
	include("../check.php");
	include("../../config.php");
	include("chk.php");

?>
<?php
				include("../../config.php");
					$con=mysql_connect($host,$user,$pass);
					mysql_select_db($db,$con);
					$sel=mysql_query("select * from bcommand where sname='".$_GET['user']."'");
					$row=mysql_fetch_array($sel);
					echo $row['soutput'];
?>