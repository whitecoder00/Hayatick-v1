<?php
	include("chk.php");
?>
<div class="panel panel-default logs">
	<center>
		<h1>
			<B>{ SPY-1218 };</B>
		</h1>
		<br>
		<hr>
		<br>
		<h4>
				<b>Code</b> : Anonymous
			<br>
			<br>
				<b>Contact</b> : Anonymous_injector@yahoo.com
			<br>
			<br>
				<b>ver</b> : 1.0.0.0
			<br>
			<br>
				<b>OS</b> : Microsoft Windows
			<br>
			<br>
			<hr>
		</h4>
	</center>
</div>