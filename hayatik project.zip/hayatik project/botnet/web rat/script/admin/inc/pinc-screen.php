<?php
	include("chk.php");
?>
<?php
	if(isset($_POST['start']))
	{
				include("pinc-nullorder.php");
				include("../config.php");
				saveorder(6);
				$con=mysqli_connect($host,$user,$pass,$db);
					mysqli_query($con,"update bscreen set swidth='".$_POST['wi']."',shight='".$_POST['hi']."' where sname='".$_GET['user']."'");
				mysqli_close($con);
	}
	if(isset($_POST['stop']))
	{
		include("pinc-nullorder.php");
		saveorder(0);
	}
					include("../config.php");
					$con=mysql_connect($host,$user,$pass);
					mysql_select_db($db,$con);
					$sel=mysql_query("select * from bscreen where sname='".$_GET['user']."'");
					$row=mysql_fetch_array($sel);
				
?>
<script>
function load()
{
				document.getElementById('sc').src="files/clinets/<?php echo $_GET['user'];?>/s.jpg";
				document.getElementById('sc').width="<?php echo $row['swidth'];?>";
				document.getElementById('sc').height="<?php echo $row['shight'];?>";
}
setTimeout(load, 100);

var ifscreen=0;
    function refreshscreen(){
        $('#screen').load('inc/pinc-screen-load.php?user=<?php echo $_GET["user"]."&pass=".$_GET["pass"];?>', function(){
				document.getElementById('sc').width="<?php echo $row['swidth'];?>";
				document.getElementById('sc').height="<?php echo $row['shight'];?>";
				if(ifscreen==1)
				{
					setTimeout(refreshscreen, 100);
				}
        });
    }
	function loadscreen()
	{
		document.getElementById('sc').src="files/clinets/<?php echo $_GET['user'];?>/s.jpg";
				document.getElementById('sc').width="<?php echo $row['swidth'];?>";
				document.getElementById('sc').height="<?php echo $row['shight'];?>";
				if(ifscreen==0)
				{		
					setTimeout(loadscreen,100);
				}
	}
</script>
<center>
	<div id="screen"><img src="" id="sc"></div>
	<br>
	<br>
	<form action="" method="post">
		<label>W :</label><input type="text" value="<?php echo $row['swidth'];?>" style="width:180px;" name="wi">
		<label>H :</label><input type="text" value="<?php echo $row['shight'];?>" style="width:180px;" name="hi">
		<br>
			<label><input type="radio" name="optradio" onclick="ifscreen=0;loadscreen();">Direct</label>
			<label><input type="radio" name="optradio" onclick="ifscreen=1;refreshscreen();">Read and Write (base64)</label>
		<br>
		<input class="btn btn-primary" type="submit" value="Start" style="width:200px;" name="start">
		<input class="btn btn-primary" type="submit" value="Stop" style="width:200px;" name="stop">
	</form>
</center>