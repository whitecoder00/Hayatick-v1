<?php
	include("chk.php");
?>

<div class="panel panel-default builder">
	<center>
		<a href="builder.zip"><input type="submit" class="btn btn-primary" value="Download Builder" name="Download"></a>
	</center>
	
</div>