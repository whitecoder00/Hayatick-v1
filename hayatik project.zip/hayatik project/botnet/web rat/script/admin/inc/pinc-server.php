<?php
	include("chk.php");
?>
<?php
	if(isset($_POST['close'])){ runserver(1); }
	if(isset($_POST['reset'])){ runserver(2); }
	if(isset($_POST['shutdown'])){ runserver(3); }
	if(isset($_POST['uninstall'])){ runserver(4); }
	
	include("pinc-nullorder.php");
	saveorder(9);
	function runserver($val)
	{
		include("../config.php");
	
			$servercon=mysqli_connect($host,$user,$pass,$db);
				mysqli_query($servercon,"update bserver set scommand='".$val."' where sname='".$_GET['user']."'");
			mysqli_close($servercon);

	}
?>
<br>
<br>
<center>
<form action="" method="post">
	<input class="btn btn-primary" type="submit" value="Close" name="close">
	<input class="btn btn-primary" type="submit" value="Restart" name="reset">
	<input class="btn btn-primary" type="submit" value="Shut down" name="shutdown">
	<input class="btn btn-primary" type="submit" value="Uninstall" name="uninstall">
</form>
</center>
