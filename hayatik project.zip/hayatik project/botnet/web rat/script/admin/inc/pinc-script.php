<?php
	include("chk.php");
?>
<?php
			if(isset($_POST['run']))
			{
				include("pinc-nullorder.php");
				include("../config.php");
				saveorder(7);
				$con=mysqli_connect($host,$user,$pass,$db);
					mysqli_query($con,"update bscript set scode='".$_POST['code']."' ,sformat='".$_POST['format']."' where sname='".$_GET['user']."'");
				mysqli_close($con);
			}
			
					include("../config.php");
					$con=mysql_connect($host,$user,$pass);
					mysql_select_db($db,$con);
					$sel=mysql_query("select * from bscript where sname='".$_GET['user']."'");
					$row=mysql_fetch_array($sel);
				
?>
<form action="" method="post">

<label>Format :</label>
<input type="text" value="<?php if($row['sformat']!="") {echo $row['sformat'];}else {echo ".bat";}?>" class="form-control" style="width:90%" name="format">
	<textarea class="form-control" style="width:100%;height:80%" name="code"><?php echo $row['scode'];?></textarea>
	<br>
		<center><input class="btn btn-primary" type="submit" value="Run" name="run"></center>
		
</form>