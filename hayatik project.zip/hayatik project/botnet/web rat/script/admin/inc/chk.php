<?php
	if(!isset($asc))
	{
		if($asc==0)
		{
			header( 'Location: ../login.html' ) ;
		}
	}
?>