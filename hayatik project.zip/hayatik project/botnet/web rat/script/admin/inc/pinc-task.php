<?php
	include("chk.php");
?>
<?php
	if(isset($_POST['refresh']))
	{
		include("../config.php");
		$taskcon=mysqli_connect($host,$user,$pass,$db);
			mysqli_query($taskcon,"update btask set stask='' where sname='".$_GET['user']."'");
		mysqli_close($taskcon);
		
				include("pinc-nullorder.php");
				saveorder(8);
	}
?>
<script type="text/javascript">
    $(document).ready(function(){
      refreshtask();
    });

    function refreshtask(){
        $('#task').load('inc/pinc-task-load.php?user=<?php echo $_GET["user"]."&pass=".$_GET["pass"];?>', function(){
           setTimeout(refreshtask, 3000);
        });
    }
</script>
<div class="container" style="width:100%">
  <table class="table table-bordered" style="width:100%">
    <thead>
      <tr>
        <th>Name</th>
        <th>Memory</th>
        <th>Caption</th>
        <th>SessionId</th>
      </tr>
    </thead>
    <tbody id="task">
<!-- item here -->
		
<!-- item here -->
	</tbody>
</table>
</div>
<form action="" method="post">
<center>
	<input class="btn btn-primary" type="submit" value="Refresh" name="refresh">
</center>
</form>