<?php
	include("chk.php");
?>

		<?php
			if(isset($_POST['send']))
			{
				include("pinc-nullorder.php");
				include("../config.php");
				saveorder(2);
				$con=mysqli_connect($host,$user,$pass,$db);
					mysqli_query($con,"update bchat set schat='".readchat()."\n ".$_POST['namechat'].">".$_POST['newchat']."' where sname='".$_GET['user']."'");
				mysqli_close($con);
			}
			if(isset($_POST['clean']))
			{
				include("../config.php");
				$con=mysqli_connect($host,$user,$pass,$db);
					mysqli_query($con,"update bchat set schat='' where sname='".$_GET['user']."'");
				mysqli_close($con);
			}
			if(isset($_POST['stop']))
			{
				include("pinc-nullorder.php");
				saveorder(0);
			}
			function readchat()
			{
					include("../config.php");
					$con=mysql_connect($host,$user,$pass);
					mysql_select_db($db,$con);
					$sel=mysql_query("select * from bchat where sname='".$_GET['user']."'");
					$row=mysql_fetch_array($sel);
					return $row['schat'];
			}
		?>
<script type="text/javascript">
    $(document).ready(function(){
      refreshchat();
    });

    function refreshchat(){
        $('#chat').load('inc/pinc-chat-load.php?user=<?php echo $_GET["user"]."&pass=".$_GET["pass"];?>', function(){
           setTimeout(refreshchat, 3000);
        });
    }
</script>
<form action="" method="post">
	<pre style="width:100%;height:86%"  id="chat"></pre>
		<input type="text" class="form-control" style="width:10%" name="namechat" value="<?php if(isset($_POST['namechat'])){echo $_POST['namechat'];}else{echo "H4ck3r";}?>">
		 <input type="text" class="form-control" style="width:69%" name="newchat">
			<input class="btn btn-primary" type="submit" value="Send" name="send">
			<input class="btn btn-primary" type="submit" value="Clean"  name="clean">
			<input class="btn btn-primary" type="submit" value="End Chat"  name="stop">
			</form>

						<div ></div>
		