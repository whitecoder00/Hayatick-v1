<?php
	include("chk.php");
?>
<?php
	if(isset($_POST['clean']))
	{
				$con=mysqli_connect($host,$user,$pass,$db);
					mysqli_query($con,"update blogs set blog='----------'");
				mysqli_close($con);
	}
					include("../config.php");
					$con=mysql_connect($host,$user,$pass);
					mysql_select_db($db,$con);
					$sel=mysql_query("select * from blogs");
					$row=mysql_fetch_array($sel);
					
?>
<div class="panel panel-default logs">
<br>
<form action="" method="post">
	<center>
	<input type="submit" class="btn btn-primary" value="Clean" name="clean"></center>
</form>
	<textarea class="form-control" style="width:100%;height:410px;margin-top:+1%;"><?php echo $row['blog'];?></textarea>
</div>