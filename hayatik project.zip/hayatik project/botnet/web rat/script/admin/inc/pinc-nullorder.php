<?php
	include("chk.php");

	function saveorder($order)
	{
			include("../config.php");
				$conorder=mysqli_connect($host,$user,$pass,$db);
				$sqlorder="update buser set sorder='".$order."'  where sname='".$_GET['user']."'";
				mysqli_query($conorder,$sqlorder);
				mysqli_close($conorder);
	}
?>