<?php
	$password="admin";
	$asc=0;
	if(isset($_GET['pass']))
	{
		if($password!=$_GET['pass'])
		{
			login();
		}
		else
		{
			$asc=1;
		}

	}
	else
	{
		login();
	}
	
	function login()
	{
		header( 'Location: login.html' ) ;
	}
?>