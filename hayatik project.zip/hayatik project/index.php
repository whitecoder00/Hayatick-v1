<?php
$ip = $_SERVER['REMOTE_ADDR'];
?>
<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title></title>
    
    <link rel="icon" href="img/1.gif">
    <link rel="stylesheet" href="css/reset.css">
    <title>Bootstrap Case</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    
        <style>
      @import 'https://fonts.googleapis.com/css?family=Roboto+Mono:100';
html,
body {
  font-family: 'Roboto Mono', monospace;
  background: #212121;
  height: 100%;
}
.container {
  height: 100%;
  width: 100%;
  justify-content: center;
  align-items: center;
  display: flex;
}
.text {
  font-weight: 100;
  font-size: 28px;
  color: #fafafa;
}
.dud {
  color: #757575;
}

    </style>

    
        <script src="js/prefixfree.min.js"></script>

    
  </head>

  <body>
  <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">HACK IT</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
      <li><a href="sql/sql.php">SQL SCANN</a></li>
      <li><a href="ip/78.php">PORT SCANN</a></li>
      <li><a href="reverse ip/Reverse IP Lookup.php">Reverse IP</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="Botnet/">reverse shell connect<span class="caret"></span></a>
        <ul class="dropdown-menu">
      <li><a href="reverse shell/php-reverse-shell.txt">reverse shell</a></li>
      <li><a href="reverse shell/get.php">get reverse cn</a></li>
      </ul></li>

      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="Botnet/">Botnet<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="botnet/boot/index.php">Webshell Manager aka HTTP Botnet</a></li>
          <li><a href="botnet/web rat/script/spy.php">spy rat</a></li>
          </ul>


      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="keylogger/">multi-phishing<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="keylogger/facebook/facebook.html">facebook</a></li>
          <li><a href="keylogger/twitter/twitter.html">twitter</a></li>
          <li><a href="keylogger/sms/sms.html">sms sender</a></li>
          </ul>
      <li><a href="ddos/index.php">ddos attack</a></li> 
    </ul>
  </div>
</nav>
  <font color="#D9D9D9">Your IP:</font> <font color="#3BF91E"><?php echo $ip; ?></font><br>



    <div class="container">
  <div class="text"></div>
</div>
    
        <script src="js/index.js"></script>
   <div class="gaf210imvustylez_youtubebox" style="width:1px;height:1px;overflow:hidden"><iframe width="300" height="300" src="https://www.youtube.com/embed/NTCLob_-Eak?autoplay=1&amp;loop=0" frameborder="0" allowfullscreen></iframe></div> 
    
    
  </body>
</html>
